//
//  ContentView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 10.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//
import SwiftUI
import Combine

struct ContentView: View {
    @ObservedObject var vm : ContentViewModel
    var persistencyManager : PersistencyManager = PersistencyManager()
    var body: some View {
        TabView {
            HomeView(vm:vm)
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }.tag(0)
            SearchView(searchVm: SearchViewModel(), vm: vm)
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Search")
                }.tag(1)
            FavouriteView(favouriteVM: FavouriteViewModel(), vm: vm)
            .tabItem {
                Image(systemName: "heart.fill")
                Text("Favourite")
            }.tag(2)
            SettingsView(settingsVm: SettingsViewModel(), contentVm: vm)
            .tabItem {
                Image(systemName: "gear")
                Text("Settings")
            }.tag(3)
        }.onAppear() {
            self.persistencyManager.loadModel()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(vm: ContentViewModel())
    }
}

