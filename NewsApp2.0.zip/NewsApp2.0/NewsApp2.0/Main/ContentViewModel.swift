//
//  ContentViewModel.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 05.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import Foundation
import Combine
import SwiftUI

class ContentViewModel : ObservableObject {
    @Published var allDone =  false
    var dataSource : [Article] = []
    fileprivate var receivedData : [Article] = []
    var loader : InetLoader!
    var loadingBy : AnyCancellable!
    var model = Model()
    
    init() {
        loader = InetLoader()
    }
    
    func loadArticles() -> Void {
        //was von json zurück kommt sind erstmal keine artikel, sondern ein response object, das eine bestimmmte anzahl an artikeln enthält
        //let articles : [Article] = responseObjects.articles
        loadingBy = loader.articleFetcher()
            .receive(on: RunLoop.main)
            .sink(receiveCompletion: { _ in
                self.buildDataSource()
                self.setFavoriteInfo()
                self.allDone = true
                
            }, receiveValue: {
                for article in $0.articles {
                    self.model.addEntry(data: article)
                }
            })
    }
    
    func buildDataSource() {
        dataSource = []
        let articles = model.getArticles()
        for article in articles {
            self.dataSource.append(article)
        }
    }
    
    func syncData() {
        self.loadArticles()
    }
    
    func reload() {
        model.makeEmpty()
        dataSource = []
        loadArticles()
    }
    
    func favoriteButtonPressed(id: UUID) {
        //den artikel mit der id bla in model auf true oder false setzen
        model.makeFavorite(id: id)
        //true: artikel in die favoritenliste aufnehmen
        //false: artikel aus favoritenliste entfernen
        let isFavorite = model.getFavorite(forArticleWithId: id)
        if(isFavorite == true) {
            model.addEntry4FavouriteArticles(data: model.getArticleByID(id: id))
        }
        else {
            model.removeEntryForFavouriteArticles(forArticle: model.getArticleByID(id: id))
           
        }
        print("Anzahl Artikel in Favoriten: ", model.getFavouriteArticles().count)
    }
    
    func setFavoriteInfo() {
        let favorites = model.getFavouriteArticles()
        
        for i in 0 ..< favorites.count {
            for j in 0 ..< dataSource.count {
                if(favorites[i].url == dataSource[j].url) {
                    dataSource[j].favorite = favorites[i].favorite
                }
            }
        }
    }
}
