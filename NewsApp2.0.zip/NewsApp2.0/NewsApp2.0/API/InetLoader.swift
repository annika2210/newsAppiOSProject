//
//  InetLoader.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 05.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import Foundation
import Combine
import SwiftUI

class InetLoader {
    
    let session :  URLSession!
    let connection : NewsApiConnection!
    let model : Model!
    
    init() {
        connection = NewsApiConnection()
        model = Model()
        session = .shared
    }
    
    func articleFetcher() -> AnyPublisher<ResponseObject, Error> {
        let category = getCategoryFromPicker()
        let url : URL = connection.createURL4Category(category: category)!
        let publisher = session.dataTaskPublisher(for: url)
            .map{data,  error in
                return data}
            .decode(type: ResponseObject.self, decoder: JSONDecoder())
        .eraseToAnyPublisher()
        
        return publisher
        
    }
    
    func articleFetcherForKeyword(keyword: String) -> AnyPublisher<ResponseObject, Error> {
        let url : URL = connection.createUrlForSearch(keyword: keyword)!
        let publisher = session.dataTaskPublisher(for: url)
            .map{data,  error in
                return data}
            .decode(type: ResponseObject.self, decoder: JSONDecoder())
        .eraseToAnyPublisher()
        
        return publisher
        
    }
    
    func getCategoryFromPicker() -> String {
        return UserDefaults.standard.string(forKey: "Kategorie") ?? "business"
        
    }
}
