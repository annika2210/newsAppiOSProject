//
//  NewsApi.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 05.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import Foundation
import SwiftUI

public struct NewsApiConnection {
    
    let key = "855ff9d9c8f14176add36e1e985fbcf1"
     let scheme = "https"
     let baseHost = "newsapi.org"
     let path = "/v2/top-headlines"
    let appid = URLQueryItem(name: "apiKey", value: "855ff9d9c8f14176add36e1e985fbcf1")
     
     public func createURL4Category(category : String) -> URL?
     {
       guard key != "" else {
         print("Provide your own APP-Key")
         return nil
       }
       var uc = URLComponents()
       uc.scheme = scheme
       uc.host = baseHost
       uc.path = path
        let country = URLQueryItem(name: "country", value: "de")
        let category = URLQueryItem(name: "category", value: category)
        uc.queryItems = [country,category,appid]
       return uc.url!
    }
    
    public func createUrlForSearch(keyword: String) -> URL? {
            guard key != "" else {
                print("Provide your own APP-Key")
                return nil
              }
           let path4Search = "/v2/everything"
           let language = URLQueryItem(name: "language", value: "de")
           let q = URLQueryItem(name: "q", value: keyword)
           var urlComp = URLComponents()
           urlComp.scheme = scheme
           urlComp.host = baseHost
           urlComp.path = path4Search
           urlComp.queryItems = [q, language, appid]
           return urlComp.url!
       }
}
