//
//  FavouriteViewModel.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 19.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import Foundation
import Combine

class FavouriteViewModel : ObservableObject {
    
    let model = Model()
    @Published var allDone : Bool = false
    var favouriteArticles : [Article] = []
    
    init() {
        favouriteArticles = model.getFavouriteArticles()
    }
    
    func reload() {
        favouriteArticles = model.getFavouriteArticles()
        allDone = true
    }
}
