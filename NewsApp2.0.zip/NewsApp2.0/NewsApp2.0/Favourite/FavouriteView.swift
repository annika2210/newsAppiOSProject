//
//  FavouriteView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 10.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import SwiftUI

struct FavouriteView: View {
    
    @ObservedObject var favouriteVM : FavouriteViewModel
    @ObservedObject var vm : ContentViewModel
    var body: some View {
         NavigationView {
                VStack {
                    List{
                        ForEach(favouriteVM.favouriteArticles) {
                               article in
                            NavigationLink(destination: DetailView(detailViewModel: DetailViewModel(article: article))) {
                                HomeListView(article: article, vm: self.vm) }
                        }
                               
                    }
                }.navigationBarTitle("Favoriten")
         }
            .onAppear() {
                self.favouriteVM.reload()
            }
    }
}

struct FavouriteView_Previews: PreviewProvider {
    static var previews: some View {
        FavouriteView(favouriteVM: FavouriteViewModel(), vm: ContentViewModel())
    }
}
