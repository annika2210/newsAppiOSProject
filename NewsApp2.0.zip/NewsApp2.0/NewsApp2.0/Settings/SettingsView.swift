//
//  SettingsView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 10.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import SwiftUI
import Combine

struct SettingsView: View {
    
    @ObservedObject var settingsVm : SettingsViewModel
    @ObservedObject var contentVm : ContentViewModel
    @State var selection = 0
    var body: some View {
            VStack {
                Section {
                    Picker(selection: $selection, label: Text("Bitte wähle deine Kategorie")) {
                        ForEach(0 ..< settingsVm.categories.count) {
                            Text(self.settingsVm.categories[$0])
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                }
                Section {
                    Text("Du hast gewählt: \(settingsVm.categories[selection]) \nEs werden jetzt im Home-Bildschirm nur noch Artikel zu dieser Kategorie angezeigt").padding()
                }
                }.navigationBarTitle("Einstellungen")
                .onDisappear() {
                let model = Model()
                model.setSelection(categoryAt: self.selection)
                let categories = model.getCategories()
                UserDefaults.standard.set(categories[self.selection], forKey: "Kategorie")
                self.contentVm.reload()
                self.contentVm.allDone = true
        }
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView(settingsVm: SettingsViewModel(), contentVm: ContentViewModel())
    }
}
