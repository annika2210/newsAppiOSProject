//
//  SettingsViewModel.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 10.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import Foundation
import Combine
import SwiftUI

class SettingsViewModel : ObservableObject {
    
    let model = Model()
    var categories : [String] = []
    
    init() {
        categories = model.getCategories()
    }
    
}
