//
//  PickerView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 10.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import SwiftUI

struct PickerView: View {
    
    var category : String
    var body: some View {
        HStack(alignment: .center) {
           Text("\(category)")
            Spacer()
        }
    }
}

