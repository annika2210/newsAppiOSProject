//
//  SearchView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 10.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import SwiftUI

struct SearchView: View {
    
    @ObservedObject var searchVm : SearchViewModel
    @ObservedObject var vm : ContentViewModel
    
    var body: some View {
        NavigationView {
        VStack {
            Spacer()
            HStack {
                Spacer()
                Text("Hier kannst du in allen verfügbaren Artikeln mit einem Schlagwort suchen.\nProbier's doch mal mit Bitcoin").bold()
                Spacer()
            }
            KeywordSearchFieldView(searchVm: searchVm)
            List {
                ForEach(searchVm.dataSource) {
                    article in
                    NavigationLink(destination: DetailView(detailViewModel: DetailViewModel(article: article))) {
                        HomeListView(article: article, vm: self.vm)
                    }
                }
            }
        }.navigationBarTitle("Suche")
        }
        
        
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView(searchVm: SearchViewModel(), vm: ContentViewModel())
    }
}
