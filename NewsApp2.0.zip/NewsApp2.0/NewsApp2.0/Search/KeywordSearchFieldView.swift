//
//  KeywordSearchFieldView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 14.01.20.
//  Copyright © 2020 Annika Pfosch. All rights reserved.
//

import SwiftUI
import Combine
import Foundation

struct KeywordSearchFieldView: View {
    @State private var keyword: String = ""
    @ObservedObject var searchVm : SearchViewModel
    var body: some View {
        HStack {
            Spacer()
            TextField("Suchwort eingeben", text: $keyword).textFieldStyle(RoundedBorderTextFieldStyle())
            Button(action: {
                self.searchVm.loadArticleswithKeyword(keyword: self.keyword)
            }) {
                Text("Los gehts")
            }
            Spacer()
        }
    }

}


