//
//  SearchViewModel.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 14.01.20.
//  Copyright © 2020 Annika Pfosch. All rights reserved.
//

import Foundation
import SwiftUI
import Combine

class SearchViewModel : ObservableObject {
    var dataSource: [Article] = []
    var loader : InetLoader!
    var loadingBy : AnyCancellable!
    var model : Model!
    @Published var allDone = false
    
    init() {
        model = Model()
        loader = InetLoader()
    
    }
    
    func loadArticleswithKeyword(keyword: String) -> Void {
          //was von json zurück kommt sind erstmal keine artikel, sondern ein response object, das eine bestimmmte anzahl an artikeln enthält
          //let articles : [Article] = responseObjects.articles
        loadingBy = loader.articleFetcherForKeyword(keyword: keyword)
              .receive(on: RunLoop.main)
              .sink(receiveCompletion: { _ in
                  self.buildDataSource()
                  self.setFavouriteInfo()
                  self.allDone = true
                  
              }, receiveValue: {
                  for article in $0.articles {
                      self.model.addEntry4SearchedArticles(data: article)
                  }
              })
      }
    
    func buildDataSource() {
        let articles = model.getSearchedArticles()
        for article in articles {
            self.dataSource.append(article)
        }
    }
    
    func reload() {
        model.makeSearchEmpty()
        dataSource = []
    }
    
    func setFavouriteInfo() {
        let favorites = model.getFavouriteArticles()
              
              for i in 0 ..< favorites.count {
                  for j in 0 ..< dataSource.count {
                      if(favorites[i].url == dataSource[j].url) {
                          dataSource[j].favorite = favorites[i].favorite
                      }
                  }
              }
    }
}
