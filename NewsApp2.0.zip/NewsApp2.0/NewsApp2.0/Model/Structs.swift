//
//  Structs.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 05.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import Foundation
public struct ResponseObject : Codable {
    var status : String?
    var totalResults: Int?
    var articles : [Article]
}

public struct Article : Codable, Identifiable {
    public var id: UUID
    var source: Source?
    var author: String?
    var title : String?
    var description : String?
    var url : String?
    var urlToImage: String?
    var publishedAt : String?
    var content : String?
    var favorite : Bool?
    
    public init(from decoder : Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        self.id = UUID()
        if let source = try? values.decode(Source.self, forKey: .source) {self.source = source}  else {source = Source(id: "no id", name: "no source available")}
        if let author = try? values.decode(String.self, forKey: .author) {self.author = author} else {author = "Unknown Author"}
        if let title = try? values.decode(String.self, forKey: .title) {self.title = title} else {title = "No title available :( "}
        if let description = try? values.decode(String.self, forKey: .description) {self.description = description} else {description = "No description available :( "}
        if let url = try? values.decode(String.self, forKey: .url) {self.url = url} else { url = "https://theuselessweb.com"}
        if let urlToImage = try? values.decode(String.self, forKey: .urlToImage) {self.urlToImage = urlToImage} else {return}
        if let publishedAt = try? values.decode(String.self, forKey: .publishedAt) {self.publishedAt = publishedAt} else {publishedAt = "no date available :( "}
        if let content = try? values.decode(String.self, forKey: .content) {self.content = content} else {content = "no content available :("}
        if let favorite = try? values.decode(Bool.self, forKey: .favorite) {self.favorite = favorite} else {favorite = false}
    }
}

public struct Source : Codable {
    var id: String?
    var name: String?
}

