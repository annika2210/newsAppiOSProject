//
//  Model.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 05.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import Foundation

fileprivate class ModelSingleton {

    static let sharedInstance = ModelSingleton()
    var informationFromJson : [ResponseObject] = []
    var articles : [Article] = []
    var categories : [String] = ["business", "sports", "entertainment", "general", "health", "science", "technology"]
    var favouriteArticles : [Article] = []
    var searchedArticles : [Article] = []
    var selection : Int = 0
    
}

//File-Gedönse
extension Model {
    
    func saveModel(to url: URL) {
        let jsonEncoder = JSONEncoder()
        let outData = try! jsonEncoder.encode(model.articles)
        do {
            try outData.write(to: url)
        }
        catch {
            print("Schreiben hat nicht funktioniert")
        }
    }
    
    func saveFavouriteModel(to url: URL) {
        let jsonEncoder = JSONEncoder()
        let outData = try! jsonEncoder.encode(model.favouriteArticles)
        do {
            try outData.write(to: url)
        }
        catch {
            print("Schreiben hat nicht funktioniert")
        }
    }
    
    func loadModel(from url : URL) {
        let pathString = url.path
        if(FileManager.default.fileExists(atPath: pathString)) {
            let inData = try! Data(contentsOf: url)
            let jsonDecoder = JSONDecoder()
            model.articles = try! jsonDecoder.decode([Article].self, from: inData)
        }
        else {
            print("Datei existiert (noch) nicht")
        }
    }
    
    func loadFavouriteModel(from url : URL) {
        let pathString = url.path
        if(FileManager.default.fileExists(atPath: pathString)) {
            let inData = try! Data(contentsOf: url)
            let jsonDecoder = JSONDecoder()
            model.favouriteArticles = try! jsonDecoder.decode([Article].self, from: inData)
        }
        else {
            print("Datei existiert (noch) nicht")
        }
    }
}

//Zugriffsschicht
class Model : NSObject {
    
    fileprivate let model = ModelSingleton.sharedInstance
    
    subscript(i : Int) -> Article {
        get {
            return model.articles[i]
        }
        set (newValue) {
            model.articles[i] = newValue
        }
    }
    
    func getArticleByID(id : UUID) -> Article {
        
        //in artikeln suchen
        for index in 0 ..< model.articles.count {
            if(id == model.articles[index].id) {
                return model.articles[index]
            }
        }
        
        //falls der artikel da nicht ist, in gesuchten Artikeln suchen
        for index in 0 ..< model.searchedArticles.count {
            if(id == model.searchedArticles[index].id) {
                return model.searchedArticles[index]
            }
        }
        
        return model.articles[0]
        
    }
    
    func getCategories() -> [String] {
        return model.categories
    }
    
    func addEntry(data: Article) {
        model.articles.append(data)
    }
    
    func addEntry4SearchedArticles(data: Article) {
        model.searchedArticles.append(data)
    }
    
    func addEntry4FavouriteArticles(data : Article) {
        model.favouriteArticles.append(data)
    }
    
    func removeEntryForFavouriteArticles(forArticle: Article) {
        for i in 0 ..< model.favouriteArticles.count {
            if(forArticle.id == model.favouriteArticles[i].id) {
                removeEntryForFavorite(at: i)
                return
            }
        }
    }
    
    func makeFavorite(id: UUID) {
        for index in 0 ..< model.articles.count {
            if(model.articles[index].id == id) {
                model.articles[index].favorite?.toggle()
            }
        }
        
        //falls der favorit in gesuchten Artikeln ist
        for index in 0 ..< model.searchedArticles.count {
            if(model.searchedArticles[index].id == id) {
                model.searchedArticles[index].favorite?.toggle()
            }
        }
        
        
    }
    
    func getFavorite(forArticleWithId: UUID) -> Bool {
        for index in 0 ..< model.articles.count {
            if(model.articles[index].id == forArticleWithId) {
                return model.articles[index].favorite!
            }
        }
        
        //falls der artikel in gesuchten artikeln ist
        for index in 0 ..< model.searchedArticles.count {
            if(model.searchedArticles[index].id == forArticleWithId) {
                return model.searchedArticles[index].favorite!
            }
        }
        
        return false
    }
    
    //über id löschen!
    func removeFavorite(forArticle: Article) {
        for i in 0 ..< model.articles.count {
            if(forArticle.id == model.articles[i].id) {
                model.articles[i].favorite = false
            }
        }
        
        //herz löschen bei gesuchten artikeln
        for i in 0 ..< model.searchedArticles.count {
            if(forArticle.id == model.searchedArticles[i].id) {
                model.searchedArticles[i].favorite = false
            }
        }
    }
    
    func removeEntry(at : Int) {
        model.articles.remove(at: at)
    }
    
    func removeEntryForFavorite(at: Int) {
        model.favouriteArticles.remove(at: at)
    }
    
    func makeEmpty() {
        model.articles = []
    }
    
    func makeFavouriteEmpty() {
        model.favouriteArticles = []
    }
    
    func makeSearchEmpty() {
        model.searchedArticles = []
    }
    
    func getCategoryCount() -> Int {
        return model.categories.count
    }
    
    func getArticles() -> [Article] {
        return model.articles
    }
    
    func getFavouriteArticles() -> [Article] {
        return model.favouriteArticles
    }
    
    func getSearchedArticles() -> [Article] {
        return model.searchedArticles
    }
    
    func getSelection() -> Int {
        return model.selection
    }
    
    func setSelection(categoryAt: Int) {
        model.selection  = categoryAt
    }
 
}

//Persistenz-Manager
class PersistencyManager {
    
    let model = Model()
    
    fileprivate func getFileName() -> URL {
        let documentPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let fileName = documentPath.appendingPathComponent("articles2.0").appendingPathExtension("txt")
        return fileName
    }
    
    fileprivate func getFileNameForFavouriteArticles() -> URL {
        let documentPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let fileName = documentPath.appendingPathComponent("favouriteArticles2.0").appendingPathExtension("txt")
        return fileName
    }
    //hiermit über ViewModel zugreifen
    func saveModel() {
        //falls dashboard auch gesichert werden soll:
        //let url = getFileName()
        //model.saveModel(to: url)
        let url2 = getFileNameForFavouriteArticles()
        model.saveFavouriteModel(to: url2)
    }
    
    func loadModel() {
        //falls dashboard auch geladen werden soll:
        //let url = getFileName()
        //model.loadModel(from: url)
        let url2 = getFileNameForFavouriteArticles()
        model.loadFavouriteModel(from: url2)
    }
}


