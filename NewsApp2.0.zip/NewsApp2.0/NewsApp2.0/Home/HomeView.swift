//
//  ContentView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 05.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import SwiftUI

struct HomeView: View {
    @ObservedObject var vm: ContentViewModel
    var body: some View {
        NavigationView {
            VStack {
                List{
                    ForEach(vm.dataSource) {
                        article in
                        NavigationLink(destination: DetailView(detailViewModel: DetailViewModel(article: article))) {
                            HomeListView(article: article, vm: self.vm)
                        }
                    }
                }
            }
            .navigationBarTitle("News App 2.0")
                .onAppear() {
                    self.vm.reload()
                }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(vm: ContentViewModel())
    }
}

