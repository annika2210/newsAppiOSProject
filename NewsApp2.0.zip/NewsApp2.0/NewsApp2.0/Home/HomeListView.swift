//
//  HomeListView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 10.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import SwiftUI

struct HomeListView: View {
    var article: Article
    @State var favorite = false
    @ObservedObject var vm: ContentViewModel
    
    var body: some View {
        HStack(alignment: .center) {
            Text("\(article.title!)")
            Spacer()
            changeImage().font(.system(size: 30)).foregroundColor(Color.red).onTapGesture {
                self.vm.favoriteButtonPressed(id: self.article.id)
                self.favorite.toggle()
            }
        }.onAppear() {
            if self.article.favorite != nil {
                self.favorite = self.article.favorite!
            }
            else {
                self.favorite = false
            }
            
        }
         
    }
    
    func changeImage() -> Image {
        switch favorite {
        case true: return Image(systemName: "heart.fill")
        case false : return Image(systemName: "heart")
        }
    }

}
