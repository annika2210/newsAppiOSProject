//
//  DetailViewModel.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 19.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import Foundation
import Combine
import SwiftUI

class DetailViewModel : ObservableObject {
    
    var idDetail : UUID!
    let m = Model()
    var article : Article!
    var loadingBy : AnyCancellable!
    var image : Image!
    var webView : WebView!
    
    init(article : Article) {
        self.article = article
        idDetail = article.id
        image = Image(systemName: "questionmark")
    }
    
    func createURLToImage() -> URL{
        let urlToImage = article.urlToImage ?? "https://www.ignant.com/wp-content/uploads/2019/05/ignant-art-andy-boot-30.jpg"
        let url = URL(string: urlToImage)
        return url!
    }
}
