//
//  DetailView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 19.12.19.
//  Copyright © 2019 Annika Pfosch. All rights reserved.
//

import SwiftUI
import Foundation

struct DetailView: View {
    
    @ObservedObject var detailViewModel : DetailViewModel
    @ObservedObject var imageStore = ImageStore()
    var body: some View {
        VStack {
            Text("\(detailViewModel.article.title!)")
                .font(.headline)
                .fontWeight(.heavy)
            Text("\(detailViewModel.article.author!)")
            Image(uiImage: imageStore.getImage()).resizable()
            .aspectRatio(contentMode: .fit)
            Text("\(detailViewModel.article.description!)")
                .font(.subheadline)
            Text("\(detailViewModel.article.content!)")
            NavigationLink(destination: WebView(url: detailViewModel.article.url!)) {
                Text("Mehr lesen")
            }
        }.onAppear {
            let url = self.detailViewModel.createURLToImage()
            UIImage.loadFrom(url: url) { image in
                self.imageStore.image =  image
            }
            
        }
    }
    
}

class ImageStore : ObservableObject {
    @Published var image : UIImage!
    func getImage() -> UIImage {
        if image != nil {
            return image
        }
        else {
            return UIImage(systemName: "questionmark")!
        }
    }
}

//struct DetailView_Previews: PreviewProvider {
//    static var previews: some View {
//        DetailView(detailViewModel: DetailViewModel(article: Article())
//    }
//}
