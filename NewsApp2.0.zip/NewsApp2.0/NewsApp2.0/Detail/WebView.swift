//
//  WebView.swift
//  NewsApp2.0
//
//  Created by Annika Pfosch on 15.01.20.
//  Copyright © 2020 Annika Pfosch. All rights reserved.
//

import SwiftUI
import WebKit
import Foundation
  
//struct WebView : UIViewRepresentable {
//
//    let request: URLRequest
//
//    func makeUIView(context: Context) -> WKWebView  {
//        return WKWebView()
//    }
//
//    func updateUIView(_ uiView: WKWebView, context: Context) {
//        uiView.load(request)
//    }
//
//}

struct WebView : UIViewRepresentable {
    
    var url : String
    func makeUIView(context: Context) -> WKWebView {
        guard let url = URL(string: self.url) else {
            return WKWebView()
        }
        
        let request = URLRequest(url: url)
        let wkWebView = WKWebView()
        wkWebView.load(request)
        return wkWebView
    }
    
    func updateUIView(_ uiView: WKWebView, context: UIViewRepresentableContext<WebView>) {
//        let url = URL(string: self.url)!
//        let request = URLRequest(url: url)
//        uiView.load(request)
    }
}

  

struct WebView_Previews : PreviewProvider {
    static var previews: some View {
        WebView(url: "https://www.youtube.com/watch?v=C5xxrCj8LC0")
    }
}

